package com.cg.lab4.bean;

public class CurrentAccount extends Account {

	public final double overdraftLimit=550;
	
	public void withdraw(double amount)
	{
		System.out.println(checkLimit(amount));
	}
	 public boolean checkLimit(double amount)
	 {
		 if(amount>=overdraftLimit)
			 return true;
		 else
			 return false;
	 }
}
