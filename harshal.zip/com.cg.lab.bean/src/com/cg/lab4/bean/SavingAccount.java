package com.cg.lab4.bean;

public class SavingAccount extends Account {

	public final double miniBalance=1000;

	public void withdraw(double amount)
	{
		if(amount-miniBalance<1000)
		{
			System.out.println("U won't have sufficient balance ");
		}
		else
			setBalance(amount-miniBalance);
	}
	
}
