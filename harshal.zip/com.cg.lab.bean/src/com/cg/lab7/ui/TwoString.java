package com.cg.lab7.ui;

import java.util.Scanner;

public class TwoString {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner scan= new Scanner(System.in);
		System.out.println("Enter the first string");
		String s1=scan.next();
		System.out.println("Enter the second string");
		String s2=scan.next();
		scan.close();
		TwoString.stringGame(s1,s2);
	}

	private static void stringGame(String s1, String s2) {
		// TODO Auto-generated method stub
		StringBuilder result1=new StringBuilder();
		StringBuilder result4=new StringBuilder();
		StringBuilder result5=new StringBuilder();
		// case1
		for(int i=0;i<s1.length();i++)
		{
			if(i%2==1)
			{
				result1.append(s2);
			}
			else
			{
				result1.append(s1.charAt(i));
			}
			
		}
		System.out.println(result1);
		// case4
		if(s2.length()%2==0)
		{
			result4.append(s2.substring(0,s2.length()/2));
			result4.append(s1);
			result4.append(s2.substring(s2.length()/2,s2.length()));
		}
		else if(s2.length()%2==1)
		{
			result4.append(s2.substring(0,s2.length()/2+1));
			result4.append(s1);
			result4.append(s2.substring(s2.length()/2+1,s2.length()));
		}
		System.out.println(result4);
		//case 5
		
	}

}
