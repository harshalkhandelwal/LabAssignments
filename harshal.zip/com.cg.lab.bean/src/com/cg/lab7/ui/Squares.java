package com.cg.lab7.ui;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

public class Squares {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Scanner scan=new Scanner(System.in);
		System.out.println("Enter the number of elements");
		int n=scan.nextInt();
		int[] elements=new int[n];
		System.out.println("Enter elements");
		for(int i=0;i<n;i++)
		{
			elements[i]=scan.nextInt();
		}
		Map<Integer,Integer> result= getSquare(elements);
		System.out.println(result);

	}

	private static Map<Integer, Integer> getSquare(int[] elements) {
		// TODO Auto-generated method stub
		List<Integer> list=new ArrayList();
		for(int range:elements)
		{
			list.add(range);
		}
		Map<Integer,Integer> findSquares=new HashMap<>();
		for(Integer range:list)
		{
			findSquares.put(range, range*range);
		}
 	
		return findSquares;
	}

}
