package com.cg.lab2.ui;

import com.cg.lab2.bean.Person;

public class PersonMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Person p=new Person("Akarti","Agrawal",Gender.F,708855);
		
		p.setFirstName("Akku");
		p.setLastName("Agrawal");
		p.setGender(Gender.F);
		p.setPhoneNumber(123456);
		
		System.out.println("First Name: "+p.getFirstName());
		System.out.println("Last Name: "+p.getLastName());
		System.out.println("Gender: "+p.getGender());
		System.out.println("Phone Number: "+ p.getPhoneNumber());
		
		System.out.println(p);
	}

}
