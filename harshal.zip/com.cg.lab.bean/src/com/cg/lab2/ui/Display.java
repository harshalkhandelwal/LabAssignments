package com.cg.lab2.ui;

public class Display {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		System.out.println("Person Details");
		System.out.println("First Name: "+"Akrati");
		System.out.println("Last Name: "+"Agrawal");
		System.out.println("Gender: "+"F");
		System.out.println("Age: "+"21");
		System.out.println("Weight: "+"52");

	}

}
