package com.cg.lab3.ui;

import java.util.Arrays;
import java.util.Scanner;

public class HalfStringGame {

	public static String[] half(String[] str)
	{
		Arrays.sort(str);
		int n=str.length;
		if(n%2==0)
		{
			for(int i=0;i<n/2;i++)
			{
				str[i]=str[i].toUpperCase();
			}
			for(int i=n/2;i<n;i++)
			{
				str[i]=str[i].toLowerCase();
			}
		}
		else
		{
			for(int i=0;i<n/2+1;i++)
			{
				str[i]=str[i].toUpperCase();
			}
			for(int i=n/2+1;i<n;i++)
			{
				str[i]=str[i].toLowerCase();
			}
		}
		return str;
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int n;
		System.out.println("Enter the number of string count");
		Scanner scan=new Scanner(System.in);
		n=scan.nextInt();
		String[] str=new String[n];
		for(int i=0;i<n;i++)
		{
			str[i]=scan.next();
		}
		scan.close();
		String[] result=HalfStringGame.half(str);
		for(int i=0;i<n;i++)
		{
			System.out.println(result[i]);
		}
		
	}

}
