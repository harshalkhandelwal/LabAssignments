package com.cg.lab3.ui;

import java.time.LocalDate;
import java.time.Period;
import java.util.Scanner;

public class DurationTwoDates {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Scanner scan=new Scanner(System.in);
		System.out.println("Enter first date:");
		int date1=scan.nextInt();
		int month1=scan.nextInt();
		int year1=scan.nextInt();
		LocalDate userGiven1=LocalDate.of(year1, month1, date1);
		System.out.println("Enter second date:");
		int date2=scan.nextInt();
		int month2=scan.nextInt();
		int year2=scan.nextInt();
		LocalDate userGiven2=LocalDate.of(year2, month2, date2);
		scan.close();
		DurationTwoDates.duration(userGiven1,userGiven2);


	}

	private static void duration(LocalDate userGiven1, LocalDate userGiven2) {
		// TODO Auto-generated method stub
		Period period=userGiven1.until(userGiven2);
		System.out.println("Days:"+ period.getDays());
		System.out.println("Months:"+period.getMonths());
		System.out.println("Years:"+ period.getYears());
		
	}

}
