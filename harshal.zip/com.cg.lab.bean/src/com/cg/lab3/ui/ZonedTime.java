package com.cg.lab3.ui;

import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.Scanner;

public class ZonedTime {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		 Scanner scan=new Scanner(System.in);
		 System.out.println("Enter zoned code in string");
		 String zoneCode=scan.nextLine();
		 scan.close();
		 ZonedTime.currentDate(zoneCode);
	}

	private static void currentDate(String zoneCode) {
		// TODO Auto-generated method stub
		
		ZonedDateTime currentTime = ZonedDateTime.now(ZoneId.of(zoneCode));
		System.out.println(currentTime);
	}

}
