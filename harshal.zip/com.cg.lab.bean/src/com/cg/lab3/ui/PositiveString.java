package com.cg.lab3.ui;

import java.util.Scanner;

public class PositiveString {

	public static boolean positive(String pos) {
		int flag=1;
		for(int i=1;i<pos.length();i++)
		{
			 if(pos.charAt(i)<pos.charAt(i-1))
			 {
				 flag=0;
				 break;
			 }
		}
		if(flag==1)
			return true;
		else
			return false;
		
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Scanner scan=new Scanner(System.in);
		System.out.println("Enter a string");
		String s=scan.nextLine();
		System.out.println(PositiveString.positive(s));
		scan.close();
	}

}
