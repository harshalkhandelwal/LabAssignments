package com.cg.lab3.ui;

import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class jobseeker {
	
	public static boolean check(String name)
	{
		String s="_job$";
		Pattern p=Pattern.compile(s);
		Matcher match=p.matcher(name);
		if(match.find()&&(name.length()>=8))
			return true;
		else
			return false;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
 
		  Scanner scan= new Scanner(System.in);
		  System.out.println("Enter your jopb profile");
		  String job=scan.nextLine();
		  scan.close();
		  System.out.println(check(job));
	}

}
