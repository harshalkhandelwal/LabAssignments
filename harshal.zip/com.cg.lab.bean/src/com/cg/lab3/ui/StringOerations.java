package com.cg.lab3.ui;

import java.util.Scanner;

public class StringOerations {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String s1;
		int option;
		
		Scanner scan=new Scanner(System.in);
		System.out.println("Enter the string");
		s1=scan.next();
		System.out.println("Enter your choice:");
		System.out.println("1.Add the string to itself.");
		System.out.println("2.Replace odd positions with #");
		System.out.println("3.Remove duplicate characters in the string");
		System.out.println("4.Change odd caharcters to upper case");
		
		option=scan.nextInt();
		scan.close();
		switch(option)
		{
		case 1: 
			StringOerations.Add(s1);
		    break;
		    
		case 2: 
			StringOerations.Replace(s1);
			break;
			
		case 3:
			StringOerations.Remove(s1);
			break;
			
		case 4:
			StringOerations.ChangeCase(s1);
			break;
		default: 
			System.out.println("Invalid Case");
			break;
		}
	}

	private static void ChangeCase(String s1) {
		// TODO Auto-generated method stub
		
		StringBuilder sbb=new StringBuilder();
		char ch=s1.charAt(0);
		sbb.append(ch);
		for(int i=1;i<s1.length();i++)
		{
			ch=s1.charAt(i);
			if(s1.charAt(i)%2!=0)
			{
				  ch=Character.toUpperCase(ch);
			}
			sbb.append(ch);
		}
		System.out.println(sbb);
	}

	private static void Remove(String s1) {
		// TODO Auto-generated method stub
		
		StringBuilder sb=new StringBuilder();
		for(int i=0;i<s1.length();i++)
		{
			char ch=s1.charAt(i);
			int index=s1.indexOf(ch,i+1);
			if(index==-1)
			{
				sb.append(ch);
			}
		}
		System.out.println(sb);
	}

	private static void Replace(String s1) {
		// TODO Auto-generated method stub
		
		StringBuilder replace=new StringBuilder(s1);
		for(int i=0;i<s1.length();i+=2) 
		{
			replace.setCharAt(i+1,'#');
	    }
		System.out.println(replace);
	}

	private static void Add(String s1) {
		// TODO Auto-generated method stub
	
		s1=s1+""+s1;
		System.out.println(s1);
	}

}
