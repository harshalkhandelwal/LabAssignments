package com.cg.lab3.ui;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;

public class Warantee {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner scan=new Scanner(System.in);
		System.out.println(" Enter product date int he form of (dd/mmm/yyyy)");
		String prodDate=scan.nextLine();
		int waranteeMonth=scan.nextInt();
		int waranteeYear=scan.nextInt();
		scan.close();
		Warantee.productExpire(prodDate,waranteeMonth,waranteeYear);
		
	}

	private static void productExpire(String productDate, int waranteeMonth, int waranteeYear) {
		// TODO Auto-generated method stub
		DateTimeFormatter fmt=DateTimeFormatter.ofPattern("dd/MM/yyyy");
		LocalDate local=LocalDate.parse(productDate, fmt);
		System.out.println("Purchase Date: "+local);
		LocalDate expireMonth=local.plusMonths(waranteeMonth);
		LocalDate expireYear=expireMonth.plusYears(waranteeYear);
		System.out.println("Expiry Date:"+ expireYear);
	}

}
