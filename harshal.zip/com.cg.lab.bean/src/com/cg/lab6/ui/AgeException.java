package com.cg.lab6.ui;

import java.util.Scanner;

class AgeOccurException extends Exception {
	
	private int age;
	
	AgeOccurException(int a)
	{
		age = a; 
	}
	
	public String toString()
	{
		return age+" is an invalid age"; 
	} 
}

class Person{
	String name;
	int age;
	
	void getDetails() throws AgeOccurException 
	{
		System.out.println("Enter your name:");
		Scanner scan=new Scanner(System.in);
		name=scan.next();
		System.out.println("Enter your age:");
		age=scan.nextInt();
		scan.close();
		if (age<15)
		throw new AgeOccurException(age);
	}
	
	void showDetails()
	{
		System.out.println("Name is: "+ name+"\nAge is: "+ age);
	}
}

public class AgeException {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Person per=new Person();
		try 
		{
			per.getDetails();
			per.showDetails();
		}
		catch (AgeOccurException e)
		{
			System.out.println(e); 
		}
		
	}

}
