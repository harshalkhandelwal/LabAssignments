package com.cg.lab5.service;

import java.util.Scanner;
import com.cg.lab5.bean.Employee;
import com.cg.lab5.exception.EmployeeException;

public class Service implements EmployeeInterface{

	Employee emp;
	@Override
	public void getDetails() throws EmployeeException{
		// TODO Auto-generated method stub
		
		Scanner scan=new Scanner(System.in);
		System.out.println("Enter employee name");
		String ename=scan.next();
		System.out.println("Enter employee designation");
		String edesig=scan.next();
		System.out.println("Enter employee id");
		long eid=scan.nextLong();
		System.out.println("Enter employee salary");
		double esal=scan.nextDouble();
		scan.close();
		emp=new Employee(eid,ename,edesig,esal);
		if(esal>3000)
			throw new EmployeeException(esal);
	}

	@Override
	public String insuranceScheme() {
		// TODO Auto-generated method stub
		if(emp.getSalary()<5000 && emp.getDesignation().equals("Clerk"))
			return "No Scheme";
		else if(emp.getSalary()>5000 && emp.getSalary()<20000 && emp.getDesignation().equals("System Associate"))
			return "Scheme C";
		else if(emp.getSalary()>=20000 && emp.getSalary()<40000 && emp.getDesignation().equals("Programmer"))
			return "Scheme B";
		else if(emp.getSalary()>=40000 && emp.getDesignation().equals("Manager"))
			return "Scheme A";
		return "Conditions didn't match";
	}

	@Override
	public void setDetails() {
		// TODO Auto-generated method stub
		System.out.println("Employee id is: "+ emp.getId());
		System.out.println("Employee name is: "+ emp.getName());
		System.out.println("Employee designation is: "+ emp.getDesignation());
		System.out.println("Employee salary is: "+ emp.getSalary());
	}
	
	
}
