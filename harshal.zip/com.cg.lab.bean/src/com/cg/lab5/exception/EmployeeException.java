package com.cg.lab5.exception;

public class EmployeeException extends Exception{

private double sal;
	
	public EmployeeException(double sal)
	{
		this.sal=sal; 
	}
	
	public String toString()
	{
		return "salary is: "+ sal+ "cannot have less than 3000 salary"; 
	}
	
}
